﻿// LICENSE:
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//
// AUTHORS:
//
//  Moritz Eberl <moritz@semiodesk.com>
//  Sebastian Faubel <sebastian@semiodesk.com>
//
// Copyright (c) Semiodesk GmbH 2015-2019

using Semiodesk.Trinity;
using System;
using System.Linq;

namespace TrinityExample
{
    class Program
    {
        /// <summary>
        /// RDF database context.
        /// </summary>
        static IModel Context { get; set; }

        static void Main()
        {
            // Create a temporary memory store.
            IStore store = StoreFactory.CreateStore("provider=dotnetrdf");

            // Uncomment to log all executed queries to the console.
            // store.Log = (query) => Console.WriteLine(query);

            // A model is the equivalent to a database context in SQL.
            Context = store.GetModel(new Urn("model:example"));

            DemoCreate();
            DemoUpdate();
            DemoDelete();

            DemoLinqQuery();
            DemoLinqVirtualization();

            DemoDataBinding();

            Console.WriteLine();
            Console.WriteLine("Press ANY key to close..");
            Console.ReadLine();
        }

        /// <summary>
        /// Demonstrates the creation of mapped resources.
        /// </summary>
        static void DemoCreate()
        {
            Console.WriteLine();
            Console.WriteLine("DemoCreate..");

            Person alice = Context.CreateResource<Person>(new Urn("person:alice"));
            alice.FirstName = "Alice";
            alice.LastName = "Doe";
            alice.BirthDate = new DateTime(2000, 1, 1);
            alice.Commit();

            Person bob = Context.CreateResource<Person>(new Urn("person:bob"));
            bob.FirstName = "Bob";
            bob.LastName = "Doe";
            bob.BirthDate = new DateTime(2000, 1, 1);
            bob.Commit();

            Person john = Context.CreateResource<Person>(new Urn("person:john"));
            john.FirstName = "John";
            john.LastName = "Doe";
            john.BirthDate = new DateTime(2010, 1, 1);
            john.Commit();

            Console.WriteLine($"Empty: {Context.IsEmpty}");
        }

        /// <summary>
        /// Demonstrates how to update mapped resources.
        /// </summary>
        static void DemoUpdate()
        {
            Console.WriteLine();
            Console.WriteLine("DemoUpdate..");

            Person alice = Context.GetResource<Person>(new Urn("person:alice"));
            Person bob = Context.GetResource<Person>(new Urn("person:bob"));
            Person john = Context.GetResource<Person>(new Urn("person:john"));

            alice.KnownPersons.Add(bob);
            alice.Commit();

            bob.KnownPersons.Add(alice);
            bob.Commit();

            john.KnownPersons.Add(alice);
            john.KnownPersons.Add(bob);
            john.Commit();
        }

        /// <summary>
        /// Demonstrates how to delete mapped resources.
        /// </summary>
        static void DemoDelete()
        {
            Console.WriteLine();
            Console.WriteLine("DemoDelete..");

            Context.DeleteResource(new Urn("person:alice"));
            Context.DeleteResource(new Urn("person:bob"));
            Context.DeleteResource(new Urn("person:john"));

            Console.WriteLine($"Empty: {Context.IsEmpty}");
        }

        /// <summary>
        /// Demonstrates how to use LINQ queries to retrieve mapped resources.
        /// </summary>
        static void DemoLinqQuery()
        {
            Console.WriteLine();
            Console.WriteLine("DemoLinqQuery..");

            for(int i = 0; i < 10; i++)
            {
                var c = Context.CreateResource<Person>();
                c.FirstName = $"John {i}";
                c.LastName = "Doe";
                c.BirthDate = new DateTime(2000, 1, 1).AddDays(i);
                c.Commit();
            }

            // Create a queryable context.
            var persons = Context.AsQueryable<Person>();

            // Select all persons born after 1st January 2000 and
            // who have a name starting with "A" or "a".
            foreach (Person p in persons.Where(
              p => p.BirthDate >= new DateTime(2000, 1, 5) &&
              p.LastName.StartsWith("d", StringComparison.InvariantCultureIgnoreCase)
            ))
            {
                Console.WriteLine($"{p.FirstName} {p.LastName}: {p.BirthDate}");
            }

            Context.Clear();
        }

        /// <summary>
        /// Demonstrates how to use LINQ queries for paged retrieval of mapped resources.
        /// </summary>
        static void DemoLinqVirtualization()
        {
            Console.WriteLine();
            Console.WriteLine("DemoLinqVirtualization..");

            for (int i = 0; i < 100; i++)
            {
                var c = Context.CreateResource<Person>();
                c.FirstName = $"John {i}";
                c.LastName = "Doe";
                c.BirthDate = new DateTime(2000, 1, 1).AddDays(i);
                c.Commit();
            }

            var persons = Context.AsQueryable<Person>();

            // Load 10 persons per page.
            var pageSize = 10;

            // 'n' is the page number.
            for (int n = 0; n < 10; n++)
            {
                Console.WriteLine($"Fetching {pageSize} persons from page {n}..");

                // Skip n pages and load the next 10 persons.
                foreach (Person p in persons.Skip(n * pageSize).Take(pageSize))
                {
                    Console.WriteLine($"{p.FirstName} {p.LastName}");
                }
            }
        }

        /// <summary>
        /// Demonstrates how to use data binding.
        /// </summary>
        static void DemoDataBinding()
        {
            Console.WriteLine();
            Console.WriteLine("DemoDataBinding..");

            using (var p = Context.CreateResource<Person>())
            {
                p.PropertyChanged += (sender, e) =>
                {
                    Console.WriteLine(e.PropertyName);
                };

                p.FirstName = "John";

                p.KnownPersons.CollectionChanged += (sender, e) =>
                {
                    Console.WriteLine(e.Action);
                };

                // We can also create a new person without the context. However, this
                // is only recommended when asserting references to other resources as
                // these resources do not have a model associated with them. Therefore
                // they cannot be committed.
                p.KnownPersons.Add(new Person(new Urn("person:alice")));
                p.KnownPersons.Clear();
            }
        }
    }
}
